### Download File

`memory1.vmem`, `memory1.vmsn` from [포렌식 강의 자료 내려받기](https://dreamhack.io/lecture/forensics-materials)
