### Download File

`memory2.vmem`, `memory2.vmsn` from [포렌식 강의 자료 내려받기](https://dreamhack.io/lecture/forensics-materials)
